export {useThemeColors as default, useThemeColors} from '../context/ThemeContext';
export type {ThemeColors as Colors} from '../context/ThemeContext';
