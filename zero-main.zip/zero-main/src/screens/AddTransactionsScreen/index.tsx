import React from 'react';
import ExpenseEntry from '../../components/molecules/ExpenseEntry';

const AddTransactionsScreen = () => {
  return <ExpenseEntry type={'Add'} />;
};

export default AddTransactionsScreen;
