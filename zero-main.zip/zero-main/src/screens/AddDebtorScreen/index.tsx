import React from 'react';
import DebtorEntry from '../../components/molecules/DebtorEntry';

const AddDebtorScreen = () => {
  return <DebtorEntry type={'Add'} />;
};

export default AddDebtorScreen;
