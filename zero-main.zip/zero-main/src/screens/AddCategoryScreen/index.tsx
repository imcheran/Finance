import React from 'react';
import CategoryEntry from '../../components/molecules/CategoryEntry';

const AddCategoryScreen = () => {
  return <CategoryEntry type={'Add'} />;
};

export default AddCategoryScreen;
